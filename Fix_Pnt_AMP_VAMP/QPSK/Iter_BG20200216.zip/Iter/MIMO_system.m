function   obj=MIMO_system(Input)

N=Input.N;
M=Input.M;
rho=Input.rho;
nuw=Input.nuw;
sigma_X=Input.sigma_X;

%% Generate x
x0 = sqrt(sigma_X)*randn(N,1);            % a dense Gaussian vector
pos=rand(N,1) < rho;
x = x0.*pos;  % insert zeros


%% System
H=randn(M,N)/sqrt(M);
w=sqrt(nuw)*randn(M,1);
y=H*x+w;


%% load parameters
obj.x=x;
obj.y=y;
obj.H=H;
obj.pos=pos;

end