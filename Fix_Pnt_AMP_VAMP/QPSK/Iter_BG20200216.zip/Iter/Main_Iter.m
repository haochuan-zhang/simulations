clc;
clear all;

%% Parameters Setting
N=1024;                 %Dimension of x
M=400;                  %dimension of y
mes=0.95;               %damping factor
Iter_Num=1e2;           %Iteration numbers
IterNum=25;
rho=0.1;                %sparse factor
snr=12;

%% Load parameters
Input.N=N;
Input.M=M;
Input.mes=mes;
Input.IterNum=IterNum;
Input.nuw=10^(-snr/10);
Input.rho=rho;
Input.sigma_X=1/rho;

%% Array setting
for kk=1:Iter_Num
    
    obj=MIMO_system(Input); 
    AMP_MSE(:,kk)=AMP_Detector(Input,obj);   
    if (mod(kk,Iter_Num/10)==0)
        disp(kk/Iter_Num*10);
    end
end

SE_AMP=AMP_SE(Input);
for ii=1:IterNum
    AMP_MSE_mean(ii,1)=mean(AMP_MSE(ii,:));
end

iter=1:IterNum;
semilogy(iter,  AMP_MSE_mean, '-ob' );   
hold on;
semilogy(iter,  SE_AMP, '*r');   
hold on;

legend('AMP','SE'); hold on;
xlabel('iteration');
ylabel('MSE(dB)');
